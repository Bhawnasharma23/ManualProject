package baiscProgram;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RegistrationparaBank {
	WebDriver driver;


	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\Vinay\\\\Desktop\\\\automation testing\\\\Browser-Extension\\\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://parabank.parasoft.com/");

	}



	@Test
	public void ParaBank() throws Exception
	{
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[1]/div/p[2]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("customer.firstName")).sendKeys("Bhawna");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.lastName")).sendKeys("Bhawna@123");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.address.street")).sendKeys("Budh Vihar");
		Thread.sleep(2000);
		driver.findElement(By.id("customer.address.city")).sendKeys("Rohini");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.address.state")).sendKeys("Delhi");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.address.zipCode")).sendKeys("110086");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.phoneNumber")).sendKeys("987643211");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.ssn")).sendKeys("98761");
		Thread.sleep(2000);
		driver.findElement(By.id("customer.username")).sendKeys("Bhawna");
        Thread.sleep(2000);
        driver.findElement(By.id("customer.password")).sendKeys("Bhawna@123");
        Thread.sleep(2000);
        driver.findElement(By.id("repeatedPassword")).sendKeys("Bhawna@123");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//input[@value='Register']")).click();
        
		}

	@AfterTest
	public void afterTest() {
		driver.close();
	}

}
