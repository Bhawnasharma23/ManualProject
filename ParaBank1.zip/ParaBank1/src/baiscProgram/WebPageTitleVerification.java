package baiscProgram;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebPageTitleVerification {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\Users\\\\\\\\Vinay\\\\\\\\Desktop\\\\\\\\automation testing\\\\\\\\Browser-Extension\\\\\\\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://parabank.parasoft.com/");
        driver.manage().window().maximize();
        
        
        System.out.println("Page title: "+driver.getTitle());
        
        System.out.println("URL: "+driver.getCurrentUrl());
        
      driver.close();
	}

}
