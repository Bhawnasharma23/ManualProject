package baiscProgram;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class URL_Verification {

	public static void main(String[] args) {

		 System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\Vinay\\\\Desktop\\\\automation testing\\\\Browser-Extension\\\\chromedriver.exe");
	        WebDriver driver = new ChromeDriver();
	        
	        // Navigate to a website
	        driver.get("https://parabank.parasoft.com/parabank/index.htm");
	        
	        // Verify the current URL
	        String currentURL = driver.getCurrentUrl();
	        
	        // Compare the current URL with the expected URL
	        String expectedURL = "https://parabank.parasoft.com/parabank/index.htm";
	        
	        if (currentURL.equals(expectedURL)) {
	            System.out.println("URL verification passed!");
	        } else {
	            System.out.println("URL verification failed.");
	        }
	        
	        // Close the WebDriver
	        driver.quit();
	    }


	}


