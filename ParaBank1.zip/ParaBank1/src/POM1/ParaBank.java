package POM1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ParaBank {
	
	public void MaximizeBrowser(WebDriver driver)
	{
		driver.manage().window().maximize();
	}

	public void url(WebDriver driver)
	{
		driver.get("https://parabank.parasoft.com/parabank/register.htm");
	}
	
	public void enterUsername(WebDriver driver,String usn)
	{
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(usn);
	}
	
	public void enterPassword(WebDriver driver,String pwd)
	{
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pwd);
	}
	public void loginButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//input[@class='button']")).click();
	}
	
	public void logOutButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"leftPanel\"]/ul/li[8]/a")).click();
	}
	public void closeDriver(WebDriver driver)
	{
		driver.close();
	}

}
