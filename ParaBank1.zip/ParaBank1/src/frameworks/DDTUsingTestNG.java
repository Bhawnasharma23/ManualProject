package frameworks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM1.ParaBank;


public class DDTUsingTestNG {
	WebDriver driver;
	
	
	  @BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\Vinay\\Desktop\\automation testing\\Browser-Extension\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies(); 
		  
		  
	  }
		  
  @Test(dataProvider ="dp")
  public void ddt(String usn, String pwd) throws Exception
  {
	  ParaBank p=new ParaBank();
	  
	  p.MaximizeBrowser(driver);
	  
		p.url(driver);
		Thread.sleep(2000);
	
		p.enterUsername(driver, usn);
		Thread.sleep(2000);

		p.enterPassword(driver, pwd);
		Thread.sleep(2000);

		p.loginButton(driver);
		Thread.sleep(2000);

		p.logOutButton(driver);
		Thread.sleep(2000);
 
	 }
  @DataProvider
	public Object[][] dp() {
		return new Object[][] {

				new Object[] {"Bhawna", "Bhawna@123"}, new Object[] {"John", "demo"},
				new Object[] {"Bhawna", "Bhawna@123" }, new Object[] {"John", "demo"},
				};
	}


  @AfterTest
  public void afterTest() {
	  driver.close();
  }

}
