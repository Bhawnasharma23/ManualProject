package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Parabank_MainClass {

	public static void main(String[] args) throws Exception
	{
System.setProperty("webdriver.chrome.driver","C:\\Users\\Vinay\\Desktop\\automation testing\\Browser-Extension\\chromedriver.exe");
		
		// Step2:create object of webdriver to Chromedriver
	    WebDriver driver = new ChromeDriver();
	    
	    Parabank p=new Parabank();
	    
	    p.url(driver);
	    Thread.sleep(2000);
	    p.FirstName(driver, "Bhawna");
	    p.LastName(driver, "Bhawna@123");
	    p.Address(driver);
	    p.City(driver);
	    p.State(driver);
	    p.Zip_Code(driver);
	    p.Phone(driver);
	    p.SSN(driver);
	    p.Username(driver);
	    p.Password(driver);
	    p.Confirm(driver);
	    p.Register(driver);
	}

}
